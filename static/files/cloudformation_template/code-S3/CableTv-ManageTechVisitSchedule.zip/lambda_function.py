import json
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError


sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')
customersTable = dynamodb.Table('CableTvCustomers')
scheduleTable = dynamodb.Table('CableTvSchedule')

def cancel_schedule(customer_id):
    print("Deleting current schedule")
    try:
        response = scheduleTable.delete_item(
              Key={
                'CustomerId': customer_id
              }
            )
        print(response)

    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            return response
        else:
            return


def get_current_schedule(customer_id):
    print("Getting current schedule")
    try:
        response = scheduleTable.query(
              KeyConditionExpression=Key('CustomerId').eq(customer_id)
            )
        print(response)

    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if response['Count'] > 0:
            return response
        else:
            return 

def get_customer_data(customer_id):
    try:
        response = customersTable.get_item(
            Key={'customerId': customer_id}
        )
                    
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if "Item" in response:
            return response['Item']
        else:
            return 


def lambda_handler(event, context):
    print(event)
    
    customer_id = event["currentIntent"]["slots"]["CustomerId"]
    current_slots = event["currentIntent"]["slots"]

    customer_data = get_customer_data(customer_id)

    if customer_data:
        print("Customer found")
        action = str(current_slots['ScheduleAction'])
        print(action)
        
        if action == "None":
            current_schedule = get_current_schedule(customer_id)
            
            if current_schedule:
                visit_date = current_schedule['Items'][0]['VisitDate']
                visit_time = current_schedule['Items'][0]['VisitTime']
                
                current_slots["ScheduleAction"] = ""
        
                response = {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "intentName": "ManageSchedule",
                        "slots": current_slots,
                        "slotToElicit": "ScheduleAction",
                        "message": {
                            "contentType": "PlainText",
                            "content": "You currently have a visit scheduled for "+visit_date+" at "+visit_time+". Do you want to reschedule or cancel?"
                        }
                    }
                }
                
                print("Returning response:")
                print(response)
                return response
                
            
            else:
                response = {
                    "dialogAction": {
                        "fulfillmentState":"Fulfilled",
                        "type":"Close",
                        "message": {
                            "contentType":"PlainText",
                            "content": "You don't have any scheduled visits."
                        }
                    }
                }
                print("Returning response:")
                print(response)
                return response
                
        
        if action == "reschedule":
            current_schedule = get_current_schedule(customer_id)
            
            
            if current_schedule:
                
                problem_type = current_schedule["Items"][0]["ProblemType"]
                current_slots = {"CustomerId": customer_id ,"ProblemType": problem_type}
                
                response = {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "intentName": "VisitSchedule",
                        "slots": current_slots,
                        "slotToElicit": "VisitDate",
                        "message": {
                            "contentType": "PlainText",
                            "content": "What is the new date for your technical visit?"
                        }
                    }
                }
                
                print("Returning response:")
                print(response)
                return response
                
            
            else:
                response = {
                    "dialogAction": {
                        "type": "ElicitSlot",
                        "intentName": "ManageSchedule",
                        "slots": current_slots,
                        "slotToElicit": "ScheduleAction",
                        "message": {
                            "contentType": "PlainText",
                            "content": "Currently you don't need any scheduled visits."
                        }
                    }
                }

                print("Returning response:")
                print(response)
                return response
                
            
        if action == "cancel":
            current_schedule = get_current_schedule(customer_id)
            
            if current_schedule:
                
                delete_schedule = cancel_schedule(customer_id)

                if delete_schedule:
                    response = {
                        "dialogAction": {
                            "fulfillmentState":"Fulfilled",
                            "type":"Close",
                            "message": {
                                "contentType":"PlainText",
                                "content": "Your visit was cancelled."
                            }
                        }
                    }
                    print("Returning response:")
                    print(response)
                    return response
    
                
                else:
                    response = {
                        "dialogAction": {
                            "fulfillmentState":"Fulfilled",
                            "type":"Close",
                            "message": {
                                "contentType":"PlainText",
                                "content": "There was a problem with your request. Please try again later."
                            }
                        }
                    }
                    print("Returning response:")
                    print(response)
                    return response
            
            else:
                response = {
                    "dialogAction": {
                        "fulfillmentState":"Fulfilled",
                        "type":"Close",
                        "message": {
                            "contentType":"PlainText",
                            "content": "You don't have any scheduled visits."
                        }
                    }
                }
                print("Returning response:")
                print(response)
                return response