import json
import boto3
from botocore.exceptions import ClientError


dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('CableTvCustomers')



def get_customer_data(customer_id):
    try:
        response = table.get_item(
            Key={'customerId': customer_id}
        )
                    
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if "Item" in response:
            return response['Item']
        else:
            return 

    
def lambda_handler(event, context):
    print(event)
    
    customer_id = event["currentIntent"]["slots"]["CustomerId"]
    customer_data = get_customer_data(customer_id)
    current_slots = event["currentIntent"]["slots"]
    

    if customer_data:
        # Validate if the problem is happening to all channels. If so, schedule technical visit
        if current_slots["ProblemType"] == "allChannels":
            # current_slots.update({'VisitDate': 'null', 'VisitTime': 'null'})
            
            response = {
                "dialogAction": {
                    "type": "ElicitSlot",
                    "intentName": "VisitSchedule",
                    "slots": current_slots,
                    "slotToElicit": "VisitDate",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Since the problem is happening to all channels, I'll schedule a technical visit for you. When are you available?"
                    }
                }
            }
            
            print("Returning response:")
            print(response)
            return response
            
            
        else:    
            print("Customer found")
            response = {
                "dialogAction": {
                    "fulfillmentState":"Fulfilled",
                    "type":"Close",
                    "message": {
                        "contentType":"PlainText",
                        "content": "Thanks for reching out. Seems that this is an intermitent problem, so I'll transfer you to an agent."
                    }
                }
            }
            print("Returning response:")
            print(response)
            return response
        
    else:
        print("Customer not found")
        print("Cleaning CustomerId slot value")
        
        current_slots["CustomerId"] = ""
        
        response = {
            "dialogAction": {
                "type": "ElicitSlot",
                "intentName": "SignalLost",
                "slots": current_slots,
                "slotToElicit": "CustomerId",
                "message": {
                    "contentType": "PlainText",
                    "content": "Sorry, I couldn't identify this customer ID. Can you provide it again?"
                }
            }
        }
        print("Returning response:")
        print(response)
        
        return response
    
    
