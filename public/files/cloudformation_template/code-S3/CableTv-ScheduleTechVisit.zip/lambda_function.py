import json
import boto3
from botocore.exceptions import ClientError


dynamodb = boto3.resource('dynamodb')
customersTable = dynamodb.Table('CableTvCustomers')
scheduleTable = dynamodb.Table('CableTvSchedule')

sns = boto3.client('sns')

def notify_customer(current_slots, customer_phone):
    
    visit_date = current_slots['VisitDate']
    visit_time = current_slots['VisitTime']
    sms_message = "Your technical visit was scheduled for "+visit_date+" at "+visit_time
    print("Sending SMS message to "+customer_phone)
    try:
        response = sns.publish(
            PhoneNumber=customer_phone,
            Message=sms_message
        )
    
        print(response)
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return response



def schedule_visit(item):
    try:
        response = scheduleTable.put_item(
            Item=item
        )
                    
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return response
        


def get_customer_data(customer_id):
    try:
        response = customersTable.get_item(
            Key={'customerId': customer_id}
        )
                    
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        if "Item" in response:
            return response['Item']
        else:
            return 



def lambda_handler(event, context):
    print(event)
    
    customer_id = event["currentIntent"]["slots"]["CustomerId"]
    customer_data = get_customer_data(customer_id)
    current_slots = event["currentIntent"]["slots"]



    if customer_data:
        print("Customer found")
        
        customer_phone = customer_data["CustomerPhone"]
        

        store_on_ddb = schedule_visit(current_slots)
        send_sns_notification = notify_customer(current_slots, customer_phone)
        
        response = {
            "dialogAction": {
                "fulfillmentState":"Fulfilled",
                "type":"Close",
                "message": {
                    "contentType":"PlainText",
                    "content": "Thank you. Your technical visit is now scheduled."
                }
            }
        }
        print("Returning response:")
        print(response)
        return response
        
    else:
        print("Customer not found")
        print("Cleaning CustomerId slot value")
        
        current_slots["CustomerId"] = ""
        
        response = {
            "dialogAction": {
                "type": "ElicitSlot",
                "intentName": "VisitSchedule",
                "slots": current_slots,
                "slotToElicit": "CustomerId",
                "message": {
                    "contentType": "PlainText",
                    "content": "Sorry, I couldn't identify your customer ID. Please et me know if you want to reschedule or cancel it."
                }
            }
        }
        print("Returning response:")
        print(response)
        
        return response
